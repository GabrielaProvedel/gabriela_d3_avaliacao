-- Cria o banco de dados
CREATE DATABASE [Catalog];
GO

-- Define qual banco de dados ser� utilizado
USE [Catalog];
GO

-- Cria a tabela Products
CREATE TABLE Users(
	Id		    VARCHAR(255) NOT NULL UNIQUE,
	[Name]		VARCHAR(255) NOT NULL,
	Email		VARCHAR(255) NOT NULL,
	Password	VARCHAR(255) NOT NULL
);
GO

-- Lista os dados da tabela
SELECT Email, Password, Id, Name FROM Users;
GO

-- Insere um registro na tabela
INSERT INTO Users (Id, [Name], Email, Password)
VALUES				 ('1', 'Gabriela', 'admin@email.com', 'admin123');
GO
