﻿using gabriela_d3_avaliacao.Interfaces;
using gabriela_d3_avaliacao.Models;
using System.Data.SqlClient;

namespace gabriela_d3_avaliacao.Repositories
{
    internal class UserRepository : UserInterface
    {
        private readonly string stringConexao = "Data source=LAPTOP-832UHI0V\\SQLEXPRESS; initial catalog=Catalog; integrated security=true;";

        public bool Exists(User user)
        {
            bool key = false;

            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string querySelectAll = "SELECT Email, Password, Id, Name FROM Users";

                con.Open();

                using (SqlCommand cmd = new(querySelectAll, con))
                {
                    SqlDataReader rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        if (user.Email == rdr["Email"].ToString() && user.Password == rdr["Password"].ToString())
                        {
                            user.Id = rdr["Id"].ToString();
                            user.Name = rdr["Name"].ToString();

                            key = true;
                        }
                    }
                }
            }
            return key;
        }

        public void Access(User user, Text text)
        {
            text.Write(user);

            Console.WriteLine("\nAcesso bem sucedido. Usuario logado na plataforma.");
        }
    }
}
