﻿using gabriela_d3_avaliacao.Models;
using gabriela_d3_avaliacao.Repositories;

namespace gabriela_d3_avaliacao
{
    internal class Program
    {
        static void Main(string[] args)
        {
            UserRepository users = new();
            Text text = new();

            string op1 = "0";

            do
            {
                Console.WriteLine("\nMENU:\n");
                Console.WriteLine("1 - Acessar");
                Console.WriteLine("2 - Cancelar\n");

                op1 = Console.ReadLine();

                switch (op1)
                {
                    case "1":
                        bool exists = false;
                        do
                        {
                            User user = new();

                            Console.WriteLine("\nE-mail: ");
                            user.Email = Console.ReadLine();

                            Console.WriteLine("Senha: ");
                            user.Password = Console.ReadLine();

                            if (users.Exists(user) == false)
                            {
                                Console.WriteLine("\nEmail e/ou senha inválidos. Tente novamente.");
                            }

                            else
                            {
                                users.Access(user, text);

                                string op2 = "0";

                                Console.WriteLine("\nMENU:\n");
                                Console.WriteLine("1 - Deslogar");
                                Console.WriteLine("2 - Encerrar sistema\n");

                                op2 = Console.ReadLine();

                                if (op2 == "1")
                                {
                                    Console.WriteLine("\nUsuario deslogado.");
                                    continue;
                                }

                                else
                                {
                                    op1 = "2";
                                    break;
                                }
                            }
                        } while (exists == false);

                        break;

                    default:
                        break;
                }

            } while (op1 != "2");
        }
    }
}