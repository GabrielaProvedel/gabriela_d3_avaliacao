﻿using gabriela_d3_avaliacao.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gabriela_d3_avaliacao.Interfaces
{
    internal interface TextInterface
    {
        void Write(User user);
    }
}
