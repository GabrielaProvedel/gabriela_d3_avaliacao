﻿using gabriela_d3_avaliacao.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gabriela_d3_avaliacao.Models
{
    internal class Text : Base, TextInterface
    {
        private const string path = "database/users.csv";

        public Text()
        {
            CreateFolderAndFile(path);
        }

        private static string PrepareLine(User user)
        {
            return $"O usuario {user.Name} ({user.Id}) acessou o sistema em {DateTime.Now.ToString()}";
        }

        public void Write(User user)
        {
            string[] line = { PrepareLine(user) };
            File.AppendAllLines(path, line);
        }
    }
}
